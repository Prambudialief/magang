<?php
echo password_hash('budi123', PASSWORD_BCRYPT);
?>
