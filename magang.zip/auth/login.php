<?php
session_start();
include "../service/log.php";
include "../service/connection.php";

$error = ""; // tempat menyimpan error

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $email = mysqli_real_escape_string($conn, $_POST['email']);
    $password = $_POST['password'];
    $role = $_POST['role']; // role dari radio button

    if ($role === 'Mentor') {

        // cek mentor
        $result = mysqli_query($conn, "SELECT * FROM mentor WHERE email='$email' LIMIT 1");

        if ($result && mysqli_num_rows($result) === 1) {
            $user = mysqli_fetch_assoc($result);

            if (password_verify($password, $user['password'])) {

                $_SESSION['mentor_id'] = $user['id'];
                $_SESSION['role'] = 'Mentor';
                $_SESSION['nama'] = $user['nama'];

                addLog($conn, $user['id'], "Mentor", "Login ke sistem");

                header("Location: ../mentor/dashboard.php");
                exit;
            } else {
                $error = "Password salah!";
            }
        } else {
            $error = "Email tidak ditemukan untuk Mentor!";
        }
    } else {

        // cek admin atau peserta
        $result = mysqli_query($conn, "SELECT * FROM users WHERE email='$email' AND role='$role' LIMIT 1");

        if ($result && mysqli_num_rows($result) === 1) {
            $user = mysqli_fetch_assoc($result);

            if (password_verify($password, $user['password'])) {

                $_SESSION['user_id'] = $user['id'];
                $_SESSION['role'] = $user['role'];
                $_SESSION['nama'] = $user['nama'];

                addLog($conn, $user['id'], $user['role'], "Login ke sistem");

                if ($user['role'] === 'Admin') {
                    header("Location: ../admin/dashboard.php");
                } else {
                    header("Location: ../peserta/dashboard.php");
                }
                exit;
            } else {
                $error = "Password salah!";
            }
        } else {
            $error = "Email tidak ditemukan untuk $role!";
        }
    }
}

$path = "C:/xampp/htdocs/magang/image/logo.jpg";
$base64 = '';
if (file_exists($path)) {
    $type = pathinfo($path, PATHINFO_EXTENSION);
    $data = file_get_contents($path);
    $base64 = 'data:image/' . $type . ';base64,' . base64_encode($data);
}
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1" />
    <title>Login</title>
    <link rel="icon" href="../image/adminpro.jpg">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Open+Sans:ital,wght@0,300..800;1,300..800&display=swap" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.5/font/bootstrap-icons.css">
</head>

<body>
    <main>
        <div class="container-fluid mt-5" style="font-family:Open Sans, sans-serif;">
            <div class="container text-center mt-4">
                <img src="<?php echo $base64; ?>" alt="Logo" class="brand-logo" oncontextmenu="return false;" draggable="false" style="width: 130px; height:130px; object-fit:cover; margin-top:20px;">
                <div>
                    <p class="mb-0 text-muted">Platform manajemen magang Basarnas untuk Peserta, Mentor, dan Admin</p>
                </div>
            </div>
            <div class="container d-flex justify-content-center mt-3">
                <div class="card shadow-lg" style="max-width: 450px; width:100%;">
                    <div class="card-body p-4">
                        <?php if (!empty($error)) : ?>
                            <div class="alert alert-danger alert-dismissible fade show" role="alert">
                                <?= htmlspecialchars($error) ?>
                                <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                            </div>
                        <?php endif; ?>
                        <ul class="nav nav-tabs mb-4" id="myTab" role="tablist">
                            <li class="nav-item" role="presentation">
                                <a class="nav-link active" id="masuk-tab" href="login.php" role="tab">Masuk</a>
                            </li>

                            <li class="nav-item" role="presentation">
                                <a class="nav-link" id="masuk-tab" href="register.php" role="tab">Daftar</a>
                            </li>
                        </ul>
                        <form method="post" action="login.php">
                            <!-- Pilih Role -->
                            <div class="btn-group w-100 mb-3" role="group">
                                <input type="radio" class="btn-check" name="role" id="peserta" value="Peserta" checked>
                                <label class="btn btn-outline-primary" for="peserta"><i class="bi bi-person"></i> Peserta</label>

                                <input type="radio" class="btn-check" name="role" id="mentor" value="Mentor">
                                <label class="btn btn-outline-success" for="mentor"><i class="bi bi-people"></i> Mentor</label>

                                <input type="radio" class="btn-check" name="role" id="admin" value="Admin">
                                <label class="btn btn-outline-danger" for="admin"><i class="bi bi-shield-lock"></i> Admin</label>
                            </div>

                            <div class="mb-3 text-start">
                                <label for="email" class="form-label">Email</label>
                                <input type="email" name="email" class="form-control" id="email" placeholder="nama@email.com" required>
                            </div>
                            <div class="mb-3 text-start">
                                <label for="password" class="form-label">Password</label>
                                <input type="password" name="password" class="form-control" id="password" placeholder="Masukkan password" required>
                            </div>
                            <button type="submit" id="submitBtn" class="btn btn-primary w-100">Login</button>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </main>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/js/bootstrap.bundle.min.js"></script>
    <script src="../asset/sb-admin/js/scripts.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/Chart.js/2.8.0/Chart.min.js"></script>
    <script src="assets/demo/chart-area-demo.js"></script>
    <script src="assets/demo/chart-bar-demo.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-MrcW6ZMFYlzcLA8Nl+NtUVF0sA7MsXsP1UyJoMp4YLEuNSfAP+JcXn/tWtIaxVXM" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/simple-datatables@7.1.2/dist/umd/simple-datatables.min.js"></script>
    <script src="../asset/sb-admin/js/datatables-simple-demo.js"></script>
    <script>
        document.addEventListener("DOMContentLoaded", () => {
            const radios = document.querySelectorAll('input[name="role"]');
            const submitBtn = document.getElementById('submitBtn');

            function updateButton(role) {
                submitBtn.textContent = `Masuk Sebagai ${role}`;
                submitBtn.className = "btn w-100";

                if (role === "Peserta") {
                    submitBtn.classList.add("btn-primary");
                } else if (role === "Mentor") {
                    submitBtn.classList.add("btn-success");
                } else if (role === "Admin") {
                    submitBtn.classList.add("btn-danger");
                }
            }

            updateButton(document.querySelector('input[name="role"]:checked').value);

            radios.forEach(radio => {
                radio.addEventListener('change', function() {
                    updateButton(this.value);
                });
            });
        });
    </script>
</body>

</html>