<div id="layoutSidenav">
    <div id="layoutSidenav_nav">
        <nav class="sb-sidenav sb-sidenav-light">
            <div style="background-color:rgb(255, 255, 255);" class="sb-sidenav-menu border">
                <div class="nav">
                    <div class="mt-3">
                        <a class="nav-link" href="../peserta/dashboard.php">
                            <div class="sb-nav-link-icon"><i class="fas fa-home"></i></div>
                            Dashboard
                        </a>
                    </div>
                    <div class="mt-3">
                        <a class="nav-link" href="../peserta/materi.php">
                            <div class="sb-nav-link-icon"><i class="fas fa-box"></i></div>
                            Materi
                        </a>
                    </div>
                    <div class="mt-3">
                        <a class="nav-link" href="../peserta/manajemenTugas.php">
                            <div class="sb-nav-link-icon"><i class="fas fa-user"></i></div>
                            Tugas
                        </a>
                    </div>
                    <div class="mt-3">
                        <a class="nav-link" href="../peserta/chatMentor.php">
                            <div class="sb-nav-link-icon"><i class="fas fa-user"></i></div>
                            Chat Mentor
                        </a>
                    </div>
                </div>
            </div>
            <div style="background-color: #EFEEEA;" class="sb-sidenav-footer">
                <div class="small">Logged in as:</div>
                Peserta
            </div>
        </nav>
    </div>

    <div id="layoutSidenav_content">
        <main>