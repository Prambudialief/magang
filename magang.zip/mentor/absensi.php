<?php
include "../template_mentor/header.php";
include "../template_mentor/navbar.php";
include "../template_mentor/sidebar.php";
?>

<?php
include "../template_mentor/footer.php";
?>